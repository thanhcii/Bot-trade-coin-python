# flake8: noqa: F401
from freqtrade.plugins.protections.iprotection import IProtection, ProtectionReturn
